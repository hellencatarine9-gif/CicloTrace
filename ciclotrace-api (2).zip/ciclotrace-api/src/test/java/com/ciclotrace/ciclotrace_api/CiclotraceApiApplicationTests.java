package com.ciclotrace.ciclotrace_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiclotraceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
