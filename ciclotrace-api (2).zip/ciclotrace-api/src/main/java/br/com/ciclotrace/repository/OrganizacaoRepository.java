package br.com.ciclotrace.repository;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import br.com.ciclotrace.model.Organizacao;

@Repository
public interface OrganizacaoRepository extends Neo4jRepository<Organizacao, Long> {
}
