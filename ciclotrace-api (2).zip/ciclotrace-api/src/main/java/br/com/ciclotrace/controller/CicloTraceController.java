package br.com.ciclotrace.controller;

import br.com.ciclotrace.service.CicloTraceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "*")
public class CicloTraceController {

    @Autowired
    private CicloTraceService cicloTraceService;

    @GetMapping("/lotes/{codigoLote}/rastreabilidade")
    public List<Map<String, Object>> getRastreabilidade(@PathVariable String codigoLote) {
        return cicloTraceService.obterRastreabilidade(codigoLote);
    }

    @GetMapping("/analytics/powerbi")
    public List<Map<String, Object>> getDadosPowerBI() {
        return cicloTraceService.obterDadosParaPowerBI();
    }
}
