package br.com.ciclotrace.controller;

import br.com.ciclotrace.model.LoteMaterial;
import br.com.ciclotrace.repository.LoteMaterialRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/lotes")
public class LoteMaterialController {

    @Autowired
    private LoteMaterialRepository repository;

    @GetMapping
    public List<LoteMaterial> listar() {
        return repository.findAll();
    }

    @PostMapping
    public LoteMaterial criar(@RequestBody LoteMaterial lote) {
        return repository.save(lote);
    }
}
