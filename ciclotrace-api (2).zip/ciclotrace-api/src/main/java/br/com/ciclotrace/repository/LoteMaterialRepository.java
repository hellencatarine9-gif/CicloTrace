package br.com.ciclotrace.repository;

import br.com.ciclotrace.model.LoteMaterial;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface LoteMaterialRepository extends Neo4jRepository<LoteMaterial, Long> {

    LoteMaterial findByCodigoLote(String codigoLote);

    @Query("MATCH (l:LoteMaterial {codigoLote: $codigoLote})-[r]-(o:Organizacao) " +
            "RETURN { " +
            "  lote: l.codigoLote, " +
            "  material: l.tipoMaterial, " +
            "  pesoKg: l.pesoKg, " +
            "  relacao: type(r), " +
            "  organizacao: o.nome, " +
            "  tipoOrganizacao: o.tipo " +
            "}")
    List<Map<String, Object>> buscarRastreabilidadePorLote(@Param("codigoLote") String codigoLote);

    @Query("MATCH (l:LoteMaterial) " +
            "OPTIONAL MATCH (f:Organizacao {tipo: 'Fornecedor'})-[:FORNECEU]->(l) " +
            "OPTIONAL MATCH (l)-[:PROCESSADO_POR]->(c:Organizacao {tipo: 'Cooperativa'}) " +
            "RETURN { " +
            "  fornecedor: COALESCE(f.nome, 'Não informado'), " +
            "  cooperativa: COALESCE(c.nome, 'Não informada'), " +
            "  lote: l.codigoLote, " +
            "  material: l.tipoMaterial, " +
            "  pesoKg: l.pesoKg " +
            "}")
    List<Map<String, Object>> buscarDadosPowerBI();
}