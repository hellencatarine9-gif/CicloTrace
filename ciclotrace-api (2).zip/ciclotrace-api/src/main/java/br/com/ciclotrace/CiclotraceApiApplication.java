package br.com.ciclotrace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiclotraceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiclotraceApiApplication.class, args);
	}

}
