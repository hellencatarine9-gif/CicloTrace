package br.com.ciclotrace.model;

import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;

@Node("LoteMaterial")
public class LoteMaterial {

    @Id
    @GeneratedValue
    private Long id;

    private String codigoLote;
    private String tipoMaterial; // Ex: PET, Aluminio, Papelao
    private Double pesoKg;

    // Construtores
    public LoteMaterial() {
    }

    public LoteMaterial(String codigoLote, String tipoMaterial, Double pesoKg) {
        this.codigoLote = codigoLote;
        this.tipoMaterial = tipoMaterial;
        this.pesoKg = pesoKg;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoLote() {
        return codigoLote;
    }

    public void setCodigoLote(String codigoLote) {
        this.codigoLote = codigoLote;
    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public Double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(Double pesoKg) {
        this.pesoKg = pesoKg;
    }
}
