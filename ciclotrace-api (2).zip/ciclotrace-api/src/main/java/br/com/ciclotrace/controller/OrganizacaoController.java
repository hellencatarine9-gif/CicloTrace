package br.com.ciclotrace.controller;

import br.com.ciclotrace.model.Organizacao;
import br.com.ciclotrace.repository.OrganizacaoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/organizacoes")
public class OrganizacaoController {

    @Autowired
    private OrganizacaoRepository repository;

    @GetMapping
    public List<Organizacao> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Organizacao criar(@RequestBody Organizacao organizacao) {
        return repository.save(organizacao);
    }
}