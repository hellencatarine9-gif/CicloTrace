package br.com.ciclotrace.service;

import br.com.ciclotrace.repository.LoteMaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CicloTraceService {

    @Autowired
    private LoteMaterialRepository loteRepository;

    public List<Map<String, Object>> obterRastreabilidade(String codigoLote) {
        return loteRepository.buscarRastreabilidadePorLote(codigoLote);
    }

    public List<Map<String, Object>> obterDadosParaPowerBI() {
        return loteRepository.buscarDadosPowerBI();
    }
}
